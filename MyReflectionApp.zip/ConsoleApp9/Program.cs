﻿class Program
{
    static void Main()
    {
        HtmlDocGenerator.GenerateDocumentation("documentation.html");
    }
}